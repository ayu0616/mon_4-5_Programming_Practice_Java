public interface Controllable {
    void left();

    void up();

    void right();

    void down();
}
